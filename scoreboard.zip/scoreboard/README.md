Add team names and score then show total matches between teams
I made a directory for the project by name scoreboard and add the ReadMe file, scoreboardlib and testcases folder in it.
The functionalities are included in the myfunctions file in the scoreboardlib folder.
In gameStart() function, initialize the score of both teams with 0 value and take input from user for the number of games to be played, team names and their scores and write them in the file.
In updateScore() function, read the file, update the scores of teams, shows updated results of teams and total game score.
In finishGame() function, remove the match from the scoreboard.