
flag=0
def gameStart():
      home_Score=0
      away_Score=0
      n_input=input("Enter the number of games : ")
      #ask use to enter team names and scores
      for i in range(int(n_input)):
        print("Add Scores for the teams")
        home_Team = input("Enter name of home team:")
        away_Team = input("Enter name of away team:")
        home_Score = input("scores for " + home_Team + ":")
        away_Score = input("scores for " + away_Team + ":")

        #Append data at the end of the text file
        file = open("scores.txt","a")
        file.write("" + home_Team + ";" + away_Team + ";" + home_Score + ";" + away_Score + ";"+"\n" )
        file.close()
        print("your score has been entered")
      user_choice=int(input("Do you want to see the updated score ?? Press 1 for YES : "))
      if user_choice == 1:
         print("choice:",user_choice)
         updateScore()

def gameFinish():
    file = open("scores.txt","w")
    #remove all the data from score board
    file.truncate(0)
    file.close()
    print("All the matches are removed from Score Board")


def updateScore():
    #show all the scores of the teams
    print("All Teams Scores")
    file = open("scores.txt","r+")
    contents=file.readlines()
    game_score=len(contents)
    #data=file.read().split()
    for line in contents:
        reading=line.split(";")
       
        home_Team = reading[0]
        away_Team = reading[1]
        home_Score = reading[2]
        away_Score = reading[3]
        print(home_Team + " - " + home_Score + ":  " +away_Team  + " - " + away_Score)
    file.close()
    print("Total Games Score..." , game_score )
    user_choice=int(input("Press 0 to finish game or 1 to start a game :"))
    if user_choice == 0:
        print("choice:",user_choice)
        gameFinish()
    elif user_choice == 1:
        gameStart()    
   
    
def main():
    gameStart()
    #updateScore()
    #displayResults()
if __name__ == "__main__":   
    main()
  
