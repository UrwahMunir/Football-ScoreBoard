import unittest
import scoreboardlib.myfunctions

class TestScores(unittest.TestCase):
    
    def test_startGame(self):
        print("")

    def test_finishGame(self):   
        print("")

    def test_updateScore(self):
        print("")